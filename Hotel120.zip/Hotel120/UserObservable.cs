﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Hotel120
{
    class UserObservable : INotifyPropertyChanged
    {

        private long id;
        public long Id
        {
            get { return id; }
            set { id = value; RaisePropertyChanged("Id"); }
        }

        
            
        

        public Kunde ConvertObservableToUser()
        {
            return new Kunde()
            {
                Anrede = this.Genre,
                Vorname = this.FirstName,
                Name= this.LastName,
                PLZ = this.Postcode,
                Ort = this.Place,
                Geburtsdatum = this.Birthday,
                Nationalitaet = this.Nationality,
                KundeID = this.Id
            };
        }

        public UserObservable(Kunde kunde)
        {
            this.Genre = kunde.Anrede;
            this.FirstName = kunde.Vorname;
            this.LastName = kunde.Name;
            this.Postcode = kunde.PLZ;
            this.Place = kunde.Ort;
            this.Birthday = kunde.Geburtsdatum;
            this.Nationality = kunde.Nationalitaet;
            this.Id = kunde.KundeID;
        }

        public UserObservable()
        {

        }

        

        private string genre;
        public string Genre
        {
            get { return genre;  }
            set { genre = value; RaisePropertyChanged("Genre"); }
        }

        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set
            { firstName = value; RaisePropertyChanged("FirstName"); }

        }
        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; RaisePropertyChanged("LastName"); }
        }
        private short postcode;
        public short Postcode
        {
            get { return postcode; }
            set { postcode = value; RaisePropertyChanged("Postcode"); }
        }
        private string place;
        public string Place
        {
            get { return place; }
            set { place = value; RaisePropertyChanged("Place"); }
        }
        private DateTime birthday;
        public DateTime Birthday
        {
            get { return birthday; }
            set { birthday = value; RaisePropertyChanged("Birthday"); }
        }

        private long Nationality;
        public long nationality
        {
            get { return nationality; }
            set { nationality = value; RaisePropertyChanged("Nationality"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
