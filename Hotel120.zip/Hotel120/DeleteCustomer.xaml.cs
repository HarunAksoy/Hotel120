﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;


namespace Hotel120
{
    /// <summary>
    /// Interaktionslogik für DeleteCustomer.xaml
    /// </summary>
    public partial class DeleteCustomer : UserControl
    {
        public DeleteCustomer()
        {
            InitializeComponent();
            
        }

       

        public static List<Kunde> kundeIDliste;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            

           

            try
            {
                kundeIDliste = new List<Kunde>();

                foreach (Kunde kunde in ReadCustomer(Convert.ToInt64(showcustomerID.Text)))
                {
                    kundeIDliste.Add(kunde);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fehler beim Auslesen:" + ex.Message);
            }
            lbID.ItemsSource = kundeIDliste;
        }


        public static List<Kunde> ReadCustomer(Int64 kundenID)
        {
            using (var db = new M120Entities())
            {
                return (from rec in db.Kundes where rec.KundeID == kundenID select rec).ToList();

            }
        }

       

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            

            var context = new M120Entities();
            Kunde kunde = (Kunde)lbID.SelectedItem;
            Kunde ManagedUser = context.Kundes.Where(u => u.KundeID == kunde.KundeID).FirstOrDefault();
            context.Kundes.Remove(ManagedUser);
            context.SaveChanges();
            deletemessage.Visibility = Visibility.Visible;

        }
    }
}






