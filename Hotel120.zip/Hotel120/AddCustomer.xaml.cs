﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hotel120
{
    /// <summary>
    /// Interaktionslogik für AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : UserControl
    {
        public static bool checkaddcustomer = false;
        private UserObservable UserObservable;

        public AddCustomer()
        {
            InitializeComponent();
        }
        public void LoadUserWithId(long id)
        {
            var context = new M120Entities();
            // SELECT * from usere where u.id = "1" limit 1;
            Kunde kunde = context.Kundes.Where(u => u.KundeID == id).FirstOrDefault();
            UserObservable = new UserObservable(kunde);
            DataContext = UserObservable;
        }
    

    static void AddCustomer_(string gender, string firstname, string lastname, short postcode, string placeofresidence, DateTime birthday, int nationality)
        {
            Kunde newcustomer = new Kunde();
            newcustomer.Anrede = gender;
            newcustomer.Vorname = firstname;
            newcustomer.Name = lastname;
            newcustomer.PLZ = postcode;
            newcustomer.Ort = placeofresidence;
            newcustomer.Geburtsdatum = birthday;
            newcustomer.Nationalitaet = nationality;

            Create(newcustomer);
           
        }

        public static Int64 Create(Kunde kunde)
        {

            if (kunde.Anrede == null) kunde.Anrede = "";
            if (kunde.Vorname == null) kunde.Vorname = "";
            if (kunde.Name == null) kunde.Name = "";
            if (kunde.Ort == null) kunde.Ort = "";
            if (kunde.Geburtsdatum == null) kunde.Geburtsdatum = DateTime.Today;
            using (var db = new M120Entities())
            {
                db.Kundes.Add(kunde);
                db.SaveChanges();
                db.Entry(kunde).Reload();
                return kunde.KundeID;
            }
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            bool caught = false;

            using (var context = new M120Entities())
            {
                context.Kundes.ToList();
            }


            try //Absturz bei falschem Datenformat wird verhindert
            {
                AddCustomer_(gender.Text, firstname.Text, lastname.Text, Convert.ToInt16(postcode.Text), placeofresidence.Text, birthday.DisplayDate, Convert.ToInt32(nationality.Text));
                
            }

            catch (Exception ex)
            {
                caught = true;
                MessageBox.Show("Fehler beim Auslesen: " + ex.Message);
  
            }

            if(!caught)

                {
                    gender.Text = "";
                    firstname.Text = "";
                    lastname.Text = "";
                    postcode.Text = "";
                    placeofresidence.Text = "";
                    birthday.DisplayDate = DateTime.Now;
                    nationality.Text = "";
                    message.Visibility = Visibility.Visible;
                }
            

           
            





        }
       

    }
}
      


    

       
    


