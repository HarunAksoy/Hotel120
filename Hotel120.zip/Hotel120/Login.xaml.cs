﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace Hotel120
{
    /// <summary>
    /// Interaktionslogik für Login.xaml
    /// </summary>
    public partial class Login : UserControl
    {
        public Login()
        {
            InitializeComponent();
        }


       




        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=BMWP2;Initial Catalog=M120;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
            SqlDataAdapter sda = new SqlDataAdapter("Select count(*) from Mitarbeiter where Username ='" + username.Text + "' and Password = '" + password.Password + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {
                Main.Children.Clear();
                Content content = new Content();
                Main.Children.Add(content);
            }
            else { MessageBox.Show("The username or password is incorrect!"); }

            if (username.Text.Length == 0)
            {
                erroremail.Content = "Enter an username.";
                erroremail.Focus();
            }
            else { erroremail.Content = ""; }


            if (password.Password.Length == 0)
            {
                errorpassword.Content = "Enter an password.";
                errorpassword.Focus();
            }
            else { errorpassword.Content = ""; }
            
        }
    }
}
            
        
          

            

    






