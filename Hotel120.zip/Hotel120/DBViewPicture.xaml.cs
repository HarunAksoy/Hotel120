﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace Hotel120
{
    /// <summary>
    /// Interaktionslogik für DBViewPicture.xaml
    /// </summary>
    public partial class DBViewPicture : UserControl
    {
        public DBViewPicture()
        {
            InitializeComponent();
        }

      
        

        private void lbpics_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=BMWP2;Initial Catalog=M120;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
            ListBoxItem lb = (lbpics.SelectedItem as ListBoxItem);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter sqa = new SqlDataAdapter
            ("Select pic from picture where name='" + lb.Content.ToString() + "'", con);
            sqa.Fill(ds);
            con.Close();
            byte[] data = (byte[])ds.Tables[0].Rows[0][0];

            MemoryStream strm = new MemoryStream();

            strm.Write(data, 0, data.Length);

            strm.Position = 0;

            System.Drawing.Image img = System.Drawing.Image.FromStream(strm);

            BitmapImage bi = new BitmapImage();

            bi.BeginInit();

            MemoryStream ms = new MemoryStream();

            img.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);

            ms.Seek(0, SeekOrigin.Begin);

            bi.StreamSource = ms;

            bi.EndInit();

            imagebox.Source = bi;


        }
    }
}
