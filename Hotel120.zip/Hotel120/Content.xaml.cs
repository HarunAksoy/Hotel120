﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Hotel120
{
    /// <summary>
    /// Interaktionslogik für Content.xaml
    /// </summary>
    public partial class Content : UserControl
    {

        public Content()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ContentChanger.Children.Clear();
            Home home = new Home();
            ContentChanger.Children.Add(home);
        }



        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ContentChanger.Children.Clear();
            ShowCustomer showcustomer = new ShowCustomer();
            ContentChanger.Children.Add(showcustomer);

            try
            {
                ShowCustomer.kundenliste = new List<Kunde>();

                foreach (Kunde kunde in ShowCustomer.GetAll())
                {
                    ShowCustomer.kundenliste.Add(kunde);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fehler beim Auslesen:" + ex.Message);
            }

            showcustomer.lbUsers.ItemsSource = ShowCustomer.kundenliste;
        }




        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ContentChanger.Children.Clear();
            AddCustomer addcustomer = new AddCustomer();
            ContentChanger.Children.Add(addcustomer);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

            ContentChanger.Children.Clear();
            DeleteCustomer deletecustomer = new DeleteCustomer();
            ContentChanger.Children.Add(deletecustomer);
        }

       



        private void Button_Click_7(object sender, RoutedEventArgs e)
        {


        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            ContentChanger.Children.Clear();
            DBAddPicture dbadd = new DBAddPicture();
            ContentChanger.Children.Add(dbadd);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            ContentChanger.Children.Clear();
            DBViewPicture dbview = new DBViewPicture();
            ContentChanger.Children.Add(dbview);

            SqlConnection con = new SqlConnection(@"Data Source=BMWP2;Initial Catalog=M120;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
            con.Open();
            DataSet ds = new DataSet();

            SqlDataAdapter sqa = new SqlDataAdapter("select name from picture", con);
            sqa.Fill(ds);

            con.Close();
            foreach (DataRow dataRow in ds.Tables[0].Rows)
            {
                ListBoxItem lbItem = new ListBoxItem();
                lbItem.Content = dataRow[0].ToString();
                dbview.lbpics.Items.Add(lbItem);


            }
        }

    }
}

